-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 15-06-2025 a las 08:09:54
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `db_exashare`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `arriendo`
--

CREATE TABLE `arriendo` (
  `id_arriendo` int(11) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `fecha_fin` datetime(6) NOT NULL,
  `fecha_inicio` datetime(6) NOT NULL,
  `precio_arriendo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `arriendo`
--

INSERT INTO `arriendo` (`id_arriendo`, `estado`, `fecha_fin`, `fecha_inicio`, `precio_arriendo`) VALUES
(1, 'PENDIENTE', '2025-07-27 00:00:00.000000', '2025-06-27 00:00:00.000000', 36190),
(2, 'PENDIENTE', '2025-07-19 00:00:00.000000', '2025-06-28 00:00:00.000000', 21729),
(3, 'PENDIENTE', '2025-06-26 00:00:00.000000', '2025-06-16 00:00:00.000000', 44156),
(4, 'PENDIENTE', '2025-07-13 00:00:00.000000', '2025-07-10 00:00:00.000000', 11774),
(5, 'PENDIENTE', '2025-07-06 00:00:00.000000', '2025-06-20 00:00:00.000000', 16732),
(6, 'PENDIENTE', '2025-07-09 00:00:00.000000', '2025-06-30 00:00:00.000000', 24851),
(7, 'PENDIENTE', '2025-07-23 00:00:00.000000', '2025-06-29 00:00:00.000000', 47515),
(8, 'ACTIVO', '2025-07-11 00:00:00.000000', '2025-06-15 00:00:00.000000', 31729),
(9, 'ACTIVO', '2025-07-06 00:00:00.000000', '2025-06-15 00:00:00.000000', 29136),
(10, 'PENDIENTE', '2025-07-21 00:00:00.000000', '2025-06-25 00:00:00.000000', 38040),
(11, 'PENDIENTE', '2025-07-19 00:00:00.000000', '2025-06-28 00:00:00.000000', 23386),
(12, 'PENDIENTE', '2025-07-13 00:00:00.000000', '2025-07-03 00:00:00.000000', 14380),
(13, 'PENDIENTE', '2025-08-04 00:00:00.000000', '2025-07-10 00:00:00.000000', 18968),
(14, 'PENDIENTE', '2025-07-14 00:00:00.000000', '2025-07-06 00:00:00.000000', 31534),
(15, 'PENDIENTE', '2025-07-16 00:00:00.000000', '2025-06-28 00:00:00.000000', 42799);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramienta`
--

CREATE TABLE `herramienta` (
  `id_herramienta` bigint(20) NOT NULL,
  `categoria` varchar(100) NOT NULL,
  `descripcion` varchar(100) NOT NULL,
  `estado` varchar(30) NOT NULL,
  `nombre` varchar(30) NOT NULL,
  `precio_herramienta` int(11) NOT NULL,
  `ubicacion` varchar(100) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramienta`
--

INSERT INTO `herramienta` (`id_herramienta`, `categoria`, `descripcion`, `estado`, `nombre`, `precio_herramienta`, `ubicacion`, `id_usuario`) VALUES
(1, 'Books, Garden & Music', 'Velit omnis at impedit laborum enim.', 'USADO', 'Practical Iron Plate', 25971, 'Rosenbaumview', 1),
(2, 'Computers', 'Cum pariatur cupiditate atque consequuntur error doloremque.', 'USADO', 'Incredible Leather Bag', 36897, 'Dooleymouth', 5),
(3, 'Computers', 'Saepe assumenda eum consequuntur tenetur esse iusto minima explicabo.', 'NUEVO', 'Sleek Wool Knife', 13213, 'Lake Hangmouth', 3),
(4, 'Books, Clothing & Jewelry', 'Optio perferendis pariatur sint placeat corrupti.', 'USADO', 'Mediocre Steel Keyboard', 29960, 'North Dominique', 5),
(5, 'Baby', 'Perspiciatis ipsum minima iure nobis illo eveniet magni ad suscipit.', 'NUEVO', 'Heavy Duty Leather Clock', 19693, 'South Tracymouth', 3),
(6, 'Health & Tools', 'Ullam culpa excepturi tenetur sequi doloremque modi ut ducimus numquam.', 'USADO', 'Aerodynamic Marble Plate', 10007, 'MacGyverfort', 5),
(7, 'Beauty', 'Harum quos natus culpa omnis.', 'USADO', 'Enormous Aluminum Lamp', 24570, 'North Salvatore', 4),
(8, 'Health', 'Tempore animi blanditiis blanditiis explicabo nesciunt reprehenderit totam sunt nobis.', 'NUEVO', 'Sleek Copper Car', 35427, 'Curtishaven', 3),
(9, 'Garden', 'Nam doloremque iste praesentium id molestiae mollitia doloribus nam.', 'USADO', 'Ergonomic Linen Clock', 24156, 'Lovettastad', 5),
(10, 'Toys', 'Consequuntur sequi cum rem cumque incidunt molestiae voluptatibus id voluptatem.', 'NUEVO', 'Gorgeous Concrete Gloves', 40693, 'Steubershire', 1),
(11, 'Grocery & Shoes', 'Magnam ducimus nesciunt porro facere deleniti iusto eligendi blanditiis.', 'USADO', 'Incredible Wooden Table', 20275, 'South Nanettebury', 2),
(12, 'Shoes', 'Ut magni ipsam ex ab qui.', 'USADO', 'Practical Copper Bottle', 21313, 'Renaburgh', 1),
(13, 'Grocery', 'Debitis ut in totam rerum.', 'USADO', 'Lightweight Plastic Plate', 12746, 'East Chadwick', 6),
(14, 'Sports', 'Perspiciatis ipsum ipsa optio accusantium ipsa quam a tempora.', 'USADO', 'Sleek Silk Bench', 23890, 'Margoton', 9),
(15, 'Automotive & Industrial', 'Rem beatae dolorem laborum sed molestias et dolorem quis.', 'NUEVO', 'Incredible Aluminum Wallet', 49284, 'Jonehaven', 4),
(16, 'Outdoors', 'Voluptates beatae voluptatum natus facere.', 'USADO', 'Heavy Duty Leather Bag', 45551, 'Ismaelfort', 4),
(17, 'Grocery & Jewelry', 'Deleniti ab repellendus beatae officia debitis quidem nostrum.', 'NUEVO', 'Mediocre Paper Wallet', 41792, 'Shanahanland', 6),
(18, 'Toys', 'Dicta recusandae quas sed perspiciatis nesciunt labore facere eaque alias.', 'NUEVO', 'Mediocre Leather Bag', 6180, 'South Nichol', 5),
(19, 'Sports', 'Sed a repellat ea vero maxime reiciendis repellat a exercitationem.', 'NUEVO', 'Aerodynamic Copper Plate', 34292, 'Lake Franktown', 3),
(20, 'Sports', 'Et blanditiis consequatur blanditiis officia repellat suscipit voluptas rerum dignissimos.', 'USADO', 'Practical Iron Knife', 39402, 'Goyettemouth', 5),
(21, 'Tools', 'Earum cum atque temporibus repudiandae nihil.', 'USADO', 'Awesome Linen Pants', 23634, 'Lake Willette', 8),
(22, 'Home', 'Est unde temporibus cupiditate iste eius assumenda veritatis debitis.', 'USADO', 'Awesome Copper Hat', 28981, 'East Abbytown', 7),
(23, 'Tools', 'Aspernatur quibusdam incidunt adipisci libero quidem.', 'USADO', 'Durable Plastic Clock', 36488, 'Jayhaven', 1),
(24, 'Shoes', 'Necessitatibus aliquam nihil commodi beatae omnis labore magni facilis aliquid.', 'USADO', 'Fantastic Rubber Table', 44732, 'North Kip', 11),
(25, 'Automotive', 'Quasi ad quidem repudiandae distinctio fugit officia.', 'NUEVO', 'Incredible Leather Wallet', 43576, 'South Mozella', 9),
(26, 'Clothing', 'Voluptatibus maiores ut ipsam cum illo deserunt.', 'USADO', 'Durable Concrete Clock', 24336, 'South Seth', 7),
(27, 'Movies', 'Explicabo aliquam ullam saepe dolore officia suscipit odit eveniet quaerat.', 'NUEVO', 'Intelligent Steel Knife', 14169, 'Port Kimbrabury', 15),
(28, 'Automotive', 'Possimus maiores doloribus ullam pariatur voluptatum aliquid ducimus labore dignissimos.', 'NUEVO', 'Intelligent Cotton Watch', 9607, 'Jaimefort', 15),
(29, 'Clothing, Electronics & Tools', 'Sapiente dicta sint aliquid aut beatae.', 'USADO', 'Fantastic Steel Bottle', 49561, 'Barberaton', 2),
(30, 'Computers', 'Fugiat consectetur est maiores quis.', 'NUEVO', 'Lightweight Paper Wallet', 47209, 'Homenickmouth', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `herramientas`
--

CREATE TABLE `herramientas` (
  `id_herramientas` int(11) NOT NULL,
  `id_arriendo` int(11) NOT NULL,
  `id_herramienta` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `herramientas`
--

INSERT INTO `herramientas` (`id_herramientas`, `id_arriendo`, `id_herramienta`) VALUES
(1, 1, 1),
(2, 2, 10),
(3, 3, 4),
(4, 3, 2),
(5, 4, 10),
(6, 5, 4),
(7, 6, 16),
(8, 7, 5),
(9, 7, 20),
(10, 8, 18),
(11, 8, 14),
(12, 9, 14),
(13, 10, 17),
(14, 10, 4),
(15, 11, 7),
(16, 12, 27),
(17, 12, 23),
(18, 13, 3),
(19, 13, 3),
(20, 14, 9),
(21, 14, 17),
(22, 15, 15),
(23, 15, 26);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `membresia`
--

CREATE TABLE `membresia` (
  `id_membresia` int(11) NOT NULL,
  `beneficios` varchar(255) NOT NULL,
  `fecha_fin` datetime(6) NOT NULL,
  `fecha_inicio` datetime(6) NOT NULL,
  `tipo` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `membresia`
--

INSERT INTO `membresia` (`id_membresia`, `beneficios`, `fecha_fin`, `fecha_inicio`, `tipo`) VALUES
(1, 'Dignissimos sed accusantium autem molestias nemo dolor quod exercitationem saepe excepturi.', '2025-12-15 00:00:00.000000', '2025-06-15 01:34:02.000000', 'Membresía 1'),
(2, 'Dignissimos magni modi harum provident deserunt numquam magni delectus quod magnam harum.', '2025-12-15 00:00:00.000000', '2025-06-15 01:34:02.000000', 'Membresía 2'),
(3, 'Dicta delectus quis fuga itaque eveniet quas deleniti voluptatum commodi cumque.', '2025-12-15 00:00:00.000000', '2025-06-15 01:34:02.000000', 'Membresía 3'),
(4, 'Debitis debitis aperiam minus officia autem sapiente exercitationem necessitatibus rerum fugit dolorem.', '2025-12-15 00:00:00.000000', '2025-06-15 01:37:42.000000', 'Membresía 1'),
(5, 'Voluptate rem quos id ex corrupti sunt natus velit voluptatum quae explicabo laboriosam.', '2025-12-15 00:00:00.000000', '2025-06-15 01:37:43.000000', 'Membresía 2'),
(6, 'Eum omnis provident nostrum officia quaerat qui sequi iste non.', '2025-12-15 00:00:00.000000', '2025-06-15 01:37:43.000000', 'Membresía 3'),
(7, 'Unde ullam atque repellendus voluptatibus libero consequatur explicabo ab ex quas.', '2025-12-15 00:00:00.000000', '2025-06-15 02:05:23.000000', 'Membresía 1'),
(8, 'Architecto totam optio repellat doloribus magnam modi corrupti.', '2025-12-15 00:00:00.000000', '2025-06-15 02:05:24.000000', 'Membresía 2'),
(9, 'Recusandae doloremque ipsa asperiores excepturi consequuntur adipisci harum ratione in dolorum eligendi odio.', '2025-12-15 00:00:00.000000', '2025-06-15 02:05:24.000000', 'Membresía 3');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resena herramientas`
--

CREATE TABLE `resena herramientas` (
  `id_resena_herramienta` int(11) NOT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `fecha` datetime(6) NOT NULL,
  `puntuacion` int(11) NOT NULL,
  `id_herramienta` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resena herramientas`
--

INSERT INTO `resena herramientas` (`id_resena_herramienta`, `comentario`, `fecha`, `puntuacion`, `id_herramienta`) VALUES
(1, 'Dicta ab assumenda dolore dicta rerum nam voluptatibus.', '2025-06-15 01:34:03.000000', 4, 1),
(2, 'Autem veniam corporis numquam aperiam ut commodi expedita possimus impedit eius harum.', '2025-06-15 01:34:03.000000', 5, 9),
(3, 'Accusantium quia aliquid nisi iusto perferendis quis molestias incidunt accusamus aperiam accusantium.', '2025-06-15 01:34:03.000000', 1, 6),
(4, 'Accusantium non vero corrupti praesentium eaque itaque impedit enim quis.', '2025-06-15 01:34:03.000000', 3, 5),
(5, 'Dolores eligendi facilis quisquam fugit soluta expedita quam nemo eveniet commodi aperiam.', '2025-06-15 01:34:03.000000', 3, 8),
(6, 'Pariatur debitis et libero dicta esse aut praesentium laboriosam vero consequuntur soluta blanditiis.', '2025-06-15 01:37:44.000000', 3, 5),
(7, 'Assumenda minus quae voluptatum nesciunt sit laudantium ipsa.', '2025-06-15 01:37:44.000000', 2, 11),
(8, 'Tempora totam quia ab magnam iure deserunt eligendi ex quos.', '2025-06-15 01:37:44.000000', 3, 12),
(9, 'Eos reiciendis blanditiis fugit aperiam vitae culpa ut doloremque praesentium debitis.', '2025-06-15 01:37:44.000000', 2, 1),
(10, 'Nesciunt accusantium aliquid alias reiciendis nesciunt totam voluptatibus numquam eligendi quia recusandae.', '2025-06-15 01:37:44.000000', 1, 1),
(11, 'Voluptatibus eius veniam tempore at iusto numquam aperiam debitis hic.', '2025-06-15 02:05:25.000000', 4, 25),
(12, 'Minima officia exercitationem incidunt sapiente eius quidem magnam.', '2025-06-15 02:05:25.000000', 3, 13),
(13, 'Saepe esse nam temporibus magni sapiente sapiente quia nihil minima nobis sit.', '2025-06-15 02:05:25.000000', 5, 16),
(14, 'Nisi facere distinctio tempore laudantium excepturi at sequi beatae labore veritatis consequuntur nihil.', '2025-06-15 02:05:25.000000', 5, 7),
(15, 'Ex occaecati laborum amet fugit voluptatem asperiores velit repudiandae.', '2025-06-15 02:05:25.000000', 4, 21);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resenas`
--

CREATE TABLE `resenas` (
  `id_resenas` int(11) NOT NULL,
  `id_resena_usuario` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resenas`
--

INSERT INTO `resenas` (`id_resenas`, `id_resena_usuario`, `id_usuario`) VALUES
(1, 1, 2),
(2, 2, 5),
(3, 3, 3),
(4, 4, 3),
(5, 5, 1),
(6, 6, 4),
(7, 7, 7),
(8, 8, 7),
(9, 9, 5),
(10, 10, 7),
(11, 11, 7),
(12, 12, 2),
(13, 13, 3),
(14, 14, 13),
(15, 15, 11);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `resena usuarios`
--

CREATE TABLE `resena usuarios` (
  `id_resena_usuario` int(11) NOT NULL,
  `comentario` varchar(255) DEFAULT NULL,
  `fecha` datetime(6) NOT NULL,
  `puntuacion` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `resena usuarios`
--

INSERT INTO `resena usuarios` (`id_resena_usuario`, `comentario`, `fecha`, `puntuacion`) VALUES
(1, 'Facere quod nobis veniam iusto nobis sequi tempora velit inventore soluta distinctio voluptatum.', '2025-06-15 01:34:02.000000', 3),
(2, 'Officiis dignissimos eius pariatur ipsa reprehenderit at magnam et sunt quae modi.', '2025-06-15 01:34:02.000000', 5),
(3, 'Quo enim modi voluptatibus ratione eligendi non maxime commodi.', '2025-06-15 01:34:03.000000', 5),
(4, 'Alias consectetur enim itaque voluptatem amet reprehenderit omnis amet similique quisquam mollitia rerum.', '2025-06-15 01:34:03.000000', 4),
(5, 'Quae occaecati ad sunt nulla quidem quas similique.', '2025-06-15 01:34:03.000000', 1),
(6, 'Tempora eveniet inventore at possimus modi odit autem eos natus doloribus tempore aliquid.', '2025-06-15 01:37:44.000000', 3),
(7, 'Ducimus atque sed in ad provident enim ad quisquam temporibus deserunt iusto.', '2025-06-15 01:37:44.000000', 1),
(8, 'Consectetur voluptatum libero necessitatibus sequi qui reprehenderit voluptas aut.', '2025-06-15 01:37:44.000000', 2),
(9, 'Debitis eligendi molestiae soluta repellendus omnis dignissimos autem doloribus aut.', '2025-06-15 01:37:44.000000', 4),
(10, 'Cum at modi unde magnam voluptate eligendi unde voluptatibus quibusdam odit.', '2025-06-15 01:37:44.000000', 1),
(11, 'Iure quos labore tempora nemo alias officiis omnis veritatis eaque.', '2025-06-15 02:05:25.000000', 2),
(12, 'Architecto voluptatem ipsam dicta nobis fuga veritatis odit consequuntur molestiae.', '2025-06-15 02:05:25.000000', 5),
(13, 'Eos adipisci laboriosam ad cupiditate ullam deleniti consequatur.', '2025-06-15 02:05:25.000000', 3),
(14, 'Blanditiis molestiae accusamus alias consectetur facilis rerum ipsa similique cumque culpa.', '2025-06-15 02:05:25.000000', 2),
(15, 'Exercitationem fuga aperiam necessitatibus ex similique saepe dolorum accusantium est.', '2025-06-15 02:05:25.000000', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_usuario`
--

CREATE TABLE `tipo_usuario` (
  `id_tipo_usuario` int(11) NOT NULL,
  `descripcion_tipo_usuario` varchar(100) DEFAULT NULL,
  `nombre_tipo_usuario` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_usuario`
--

INSERT INTO `tipo_usuario` (`id_tipo_usuario`, `descripcion_tipo_usuario`, `nombre_tipo_usuario`) VALUES
(1, 'Usuario que arrienda herramientas', 'Arrendador'),
(2, 'Usuario que arrienda herramientas de otros', 'Arrendatario');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuario`
--

CREATE TABLE `usuario` (
  `id_usuario` int(11) NOT NULL,
  `contraseña` varchar(50) NOT NULL,
  `direccion` varchar(100) NOT NULL,
  `email` varchar(50) NOT NULL,
  `nombre_usuario` varchar(20) NOT NULL,
  `telefono` varchar(20) NOT NULL,
  `id_membresia` int(11) DEFAULT NULL,
  `id_tipo_usuario` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `usuario`
--

INSERT INTO `usuario` (`id_usuario`, `contraseña`, `direccion`, `email`, `nombre_usuario`, `telefono`, `id_membresia`, `id_tipo_usuario`) VALUES
(1, 'ah4m0i98lo3', '0843 Roscoe Forge', 'kristeen.zulauf@yahoo.com', 'tameka.rowe', '(730) 681-5968', 1, 1),
(2, 'n0r02pmj3xrkqm45', '899 Greenfelder Trafficway', 'desmond.homenick@hotmail.com', 'mikel.ferry', '(472) 448-6130', 2, 1),
(3, '84du7d9je', '427 Oren Spring', 'jamel.cremin@gmail.com', 'lyla.collier', '(505) 662-0594', 1, 1),
(4, 'l9sj5668im', '072 Alejandra Ville', 'monte.stroman@gmail.com', 'shaunna.gutmann', '(985) 897-1317', 3, 1),
(5, '01416540va1', '96794 Leonard Extensions', 'walter.metz@gmail.com', 'mike.schmidt', '(305) 251-7929', 3, 1),
(6, '53x3wx39u3595y', '80966 Witting Oval', 'owen.lakin@hotmail.com', 'jospeh.roob', '(730) 229-0131', 3, 2),
(7, '87e3cut9q92', '389 Barton Alley', 'patricia.ritchie@gmail.com', 'shanda.turcotte', '(472) 462-1522', 5, 1),
(8, 'q9i86296m2p05', '8928 Emmerich Union', 'tamisha.kertzmann@hotmail.com', 'rob.bosco', '(305) 227-1327', 5, 1),
(9, '6ldx3ma98u0os3r', '595 Swift Plaza', 'orville.dibbert@yahoo.com', 'jacelyn.goldner', '(305) 860-9203', 4, 1),
(10, '0u16cj0rfq333r', '60129 Medhurst Island', 'elois.kessler@yahoo.com', 'valentine.cronin', '(505) 644-8840', 6, 1),
(11, '731a41d8ec9230', '138 Klein Heights', 'jamie.jakubowski@yahoo.com', 'flora.mayert', '(828) 235-1465', 2, 1),
(12, '5cx65z9nhxszq78', '403 Considine Glens', 'granville.brakus@yahoo.com', 'madie.wolf', '(305) 694-9289', 9, 1),
(13, '3169f87933', '1660 Runolfsson Crest', 'marcellus.altenwerth@hotmail.com', 'freeda.wunsch', '(215) 750-6349', 1, 1),
(14, '21s792ldrd238s', '37170 Gutmann Lights', 'cordelia.turner@gmail.com', 'jamal.stiedemann', '(472) 411-0053', 9, 1),
(15, '763hrz69653t', '519 Batz Glen', 'renato.stanton@yahoo.com', 'doyle.dooley', '(730) 220-4555', 5, 2);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `arriendo`
--
ALTER TABLE `arriendo`
  ADD PRIMARY KEY (`id_arriendo`);

--
-- Indices de la tabla `herramienta`
--
ALTER TABLE `herramienta`
  ADD PRIMARY KEY (`id_herramienta`),
  ADD KEY `FK99l8x0cjhumvony2alelxgngc` (`id_usuario`);

--
-- Indices de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  ADD PRIMARY KEY (`id_herramientas`),
  ADD KEY `FK7719vcoq30vyjjihvwiy4mlve` (`id_arriendo`),
  ADD KEY `FKb8xi7o8aiu84o2xjbuf1mqd5` (`id_herramienta`);

--
-- Indices de la tabla `membresia`
--
ALTER TABLE `membresia`
  ADD PRIMARY KEY (`id_membresia`);

--
-- Indices de la tabla `resena herramientas`
--
ALTER TABLE `resena herramientas`
  ADD PRIMARY KEY (`id_resena_herramienta`),
  ADD KEY `FK2us8o0a4lwtjgxw38w7nk27o4` (`id_herramienta`);

--
-- Indices de la tabla `resenas`
--
ALTER TABLE `resenas`
  ADD PRIMARY KEY (`id_resenas`),
  ADD KEY `FKeku3o70paqaetcxrhaegwpvnu` (`id_resena_usuario`),
  ADD KEY `FKt4ih3ur3d8r0d5oq8n9urngeu` (`id_usuario`);

--
-- Indices de la tabla `resena usuarios`
--
ALTER TABLE `resena usuarios`
  ADD PRIMARY KEY (`id_resena_usuario`);

--
-- Indices de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  ADD PRIMARY KEY (`id_tipo_usuario`);

--
-- Indices de la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`id_usuario`),
  ADD KEY `FK9eb50chtkfrxtwgir3ct7chds` (`id_membresia`),
  ADD KEY `FKr9xk0brid147iaydo8j47o9p2` (`id_tipo_usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `arriendo`
--
ALTER TABLE `arriendo`
  MODIFY `id_arriendo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `herramienta`
--
ALTER TABLE `herramienta`
  MODIFY `id_herramienta` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT de la tabla `herramientas`
--
ALTER TABLE `herramientas`
  MODIFY `id_herramientas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de la tabla `membresia`
--
ALTER TABLE `membresia`
  MODIFY `id_membresia` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de la tabla `resena herramientas`
--
ALTER TABLE `resena herramientas`
  MODIFY `id_resena_herramienta` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `resenas`
--
ALTER TABLE `resenas`
  MODIFY `id_resenas` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `resena usuarios`
--
ALTER TABLE `resena usuarios`
  MODIFY `id_resena_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT de la tabla `tipo_usuario`
--
ALTER TABLE `tipo_usuario`
  MODIFY `id_tipo_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuario`
--
ALTER TABLE `usuario`
  MODIFY `id_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `herramienta`
--
ALTER TABLE `herramienta`
  ADD CONSTRAINT `FK99l8x0cjhumvony2alelxgngc` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `herramientas`
--
ALTER TABLE `herramientas`
  ADD CONSTRAINT `FK7719vcoq30vyjjihvwiy4mlve` FOREIGN KEY (`id_arriendo`) REFERENCES `arriendo` (`id_arriendo`),
  ADD CONSTRAINT `FKb8xi7o8aiu84o2xjbuf1mqd5` FOREIGN KEY (`id_herramienta`) REFERENCES `herramienta` (`id_herramienta`);

--
-- Filtros para la tabla `resena herramientas`
--
ALTER TABLE `resena herramientas`
  ADD CONSTRAINT `FK2us8o0a4lwtjgxw38w7nk27o4` FOREIGN KEY (`id_herramienta`) REFERENCES `herramienta` (`id_herramienta`);

--
-- Filtros para la tabla `resenas`
--
ALTER TABLE `resenas`
  ADD CONSTRAINT `FKeku3o70paqaetcxrhaegwpvnu` FOREIGN KEY (`id_resena_usuario`) REFERENCES `resena usuarios` (`id_resena_usuario`),
  ADD CONSTRAINT `FKt4ih3ur3d8r0d5oq8n9urngeu` FOREIGN KEY (`id_usuario`) REFERENCES `usuario` (`id_usuario`);

--
-- Filtros para la tabla `usuario`
--
ALTER TABLE `usuario`
  ADD CONSTRAINT `FK9eb50chtkfrxtwgir3ct7chds` FOREIGN KEY (`id_membresia`) REFERENCES `membresia` (`id_membresia`),
  ADD CONSTRAINT `FKr9xk0brid147iaydo8j47o9p2` FOREIGN KEY (`id_tipo_usuario`) REFERENCES `tipo_usuario` (`id_tipo_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
