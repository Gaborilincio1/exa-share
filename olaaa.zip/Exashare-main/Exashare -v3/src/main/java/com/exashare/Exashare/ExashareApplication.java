package com.exashare.Exashare;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExashareApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExashareApplication.class, args);
	}

}
